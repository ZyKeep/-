﻿#include "TestProject2.h"

TestProject2::TestProject2(QWidget *parent)
    : QMainWindow(parent)
{
	ui.setupUi(this);
	QString str = tr("工程B字段");
	str = tr("字段1");
	str = tr("字段2");
	str = tr("字段3");
	str = tr("字段4");
	str = tr("字段5");
}

TestProject2::~TestProject2()
{}
