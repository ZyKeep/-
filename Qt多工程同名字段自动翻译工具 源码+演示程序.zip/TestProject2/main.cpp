﻿#include "TestProject2.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TestProject2 w;
    w.show();
    return a.exec();
}
