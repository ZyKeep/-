﻿#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_TestProject2.h"

class TestProject2 : public QMainWindow
{
    Q_OBJECT

public:
    TestProject2(QWidget *parent = nullptr);
    ~TestProject2();

private:
    Ui::TestProject2Class ui;
};
