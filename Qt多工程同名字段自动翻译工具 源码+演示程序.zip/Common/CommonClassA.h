﻿#pragma once

#include <QObject>

class CommonClassA  : public QObject
{
	Q_OBJECT

public:
	CommonClassA(QObject *parent);
	~CommonClassA();
};
