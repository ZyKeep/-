﻿#pragma once

#include <QObject>

class CommonClassB  : public QObject
{
	Q_OBJECT

public:
	CommonClassB(QObject *parent);
	~CommonClassB();
};
