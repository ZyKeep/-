﻿#include "CommonClassA.h"

CommonClassA::CommonClassA(QObject *parent)
	: QObject(parent)
{
	QString str = tr("公共类A的翻译测试字段");
	str = tr("字段1");
	str = tr("字段2");
	str = tr("字段3");
	str = tr("字段4");
	str = tr("字段5");
}

CommonClassA::~CommonClassA()
{}
