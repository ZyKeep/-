﻿#include "XmlAPI.h"
#include <QFile>
#include <QTextStream>

XmlAPI::XmlAPI(QString strXmlFilePath) :
	mXmlFilePath(strXmlFilePath)
{
}

bool XmlAPI::Read()
{
	QFile file(mXmlFilePath);
	if (!QFile::exists(mXmlFilePath))
	{
		return false;
	}
	if (!file.open(QFile::ReadOnly | QFile::Text))
	{
		return false;
	}

	QString error;
	int row = 0, column = 0;
	if (!mDoc.setContent(&file, false, &error, &row, &column))
	{
		file.close();
		return false;
	}
	file.close();
	if (mDoc.isNull())
	{
		return false;
	}

	mRoot = mDoc.documentElement();
	if (mRoot.isNull())
	{
		return false;
	}
	return true;
}

QDomElement XmlAPI::GetChild(QDomElement &node, QString name)
{
	return node.firstChildElement(name);
}

QString XmlAPI::GetChildAttr(QDomElement& node, QString name)
{
	return node.firstChildElement(name).attribute("value");
}

QDomElement XmlAPI::GetRootChild(QString name)
{
	return mRoot.firstChildElement(name);
}

QList<QDomElement> XmlAPI::GetChilds(QDomElement &node, QString name)
{
	QList<QDomElement> childs;
	QDomElement child = node.firstChildElement(name);
	while (!child.isNull())
	{
		childs.append(child);
		child = child.nextSiblingElement(name);
	}
	return childs;
}

QString XmlAPI::GetAttr(QDomElement &node, QString name)
{
	return node.attribute(name);
}

void XmlAPI::Create()
{
	QDomProcessingInstruction instruction = mDoc.createProcessingInstruction("xml", "version=\"1.0\" encoding=\"UTF-8\"");
	mDoc.appendChild(instruction);
	mRoot = mDoc.createElement("Root");
	mDoc.appendChild(mRoot);
}

bool XmlAPI::Write()
{
	QFile::remove(mXmlFilePath);
	QFile file(mXmlFilePath);

	if (!file.open(QFile::WriteOnly | QFile::Text))
	{
		QString err = file.errorString();
		return false;
	}
	QTextStream out(&file);
	mDoc.save(out, 4);
	file.flush();
	file.close();
	return true;
}

QDomElement XmlAPI::AddRootChild(QString name)
{
	return AddChild(mRoot, name);
}

QDomElement XmlAPI::AddChild(QDomElement &node, QString name)
{
	QDomElement child = mDoc.createElement(name);
	node.appendChild(child);
	return child;
}

QDomElement XmlAPI::AddChildAttr(QDomElement &node, QString name, QString text)
{
	QDomElement child = mDoc.createElement(name);
	//QDomText textNode = mDoc.createTextNode(text);
	//child.appendChild(textNode);
	child.setAttribute("value", text);

	node.appendChild(child);
	return child;
}

QDomElement XmlAPI::AddChildAttr(QDomElement &node, QString name, int text)
{
	return AddChildAttr(node, name, QString::number(text));
}

QDomElement XmlAPI::AddChildAttr(QDomElement &node, QString name, bool text)
{
	return AddChildAttr(node, name, QString::number(text ? 1 : 0));
}

void XmlAPI::UpdateChildAttr(QDomElement &node, QString name, QString text)
{
	QDomElement child = node.firstChildElement(name);
	child.setAttribute("value", text);
}