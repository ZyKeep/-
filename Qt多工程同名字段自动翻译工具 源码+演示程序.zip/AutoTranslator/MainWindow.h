﻿#pragma once

#include <QMainWindow>
#include "ui_MainWindow.h"

//一个类名下的所有字段翻译内容
class ClassTranslatorData 
{
public:
	void Add(QString key, QString value)
	{
		if (!mapTranslators.contains(key))
		{
			mapTranslators[key] = value;
		}
	}
	QString Find(QString key)
	{
		if (mapTranslators.contains(key))
		{
			return mapTranslators[key];
		}
		return "";
	}

private:
	QMap<QString, QString> mapTranslators;
};



class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

	QStringList FindTsFilesInDir();
	void Tip(QString text = "");

public slots:
	void on_btnOK_clicked();

private:
    Ui::MainWindowClass ui;
};
