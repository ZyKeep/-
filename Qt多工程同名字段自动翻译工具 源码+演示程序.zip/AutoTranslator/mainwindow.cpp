﻿#include "MainWindow.h"
#include "QDir"
#include "QDirIterator"
#include "xmlapi.h"
#include <QMap>

#pragma execution_character_set("utf-8")


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);

	QStringList lstTsFiles = FindTsFilesInDir();
	Tip("发现ts文件 " + QString::number(lstTsFiles.size()) + " 个：");
	for (QString file : lstTsFiles)
	{
		Tip(file);
	}
	Tip();
	Tip();
	Tip();
}

MainWindow::~MainWindow()
{}


QStringList MainWindow::FindTsFilesInDir()
{
	QStringList tsFilePaths;

	// 获取程序目录路径
	QDir dir(qApp->applicationDirPath());
	//QDir dir("D:/CCS");

	// 使用 QDirIterator 遍历目录树，查找所有 .ts 后缀的文件
	QDirIterator it(dir.absolutePath(), QStringList() << "*.ts", QDir::Files | QDir::NoSymLinks, QDirIterator::Subdirectories);
	while (it.hasNext()) {
		QString filePath = it.next();
		tsFilePaths.append(filePath);
	}

	return tsFilePaths;
}

void MainWindow::Tip(QString text)
{
	ui.textEdit->append(text);
}

void MainWindow::on_btnOK_clicked()
{
	QMap<QString, ClassTranslatorData*> mapAllClassTranslatorData;
	QStringList lstTsFiles = FindTsFilesInDir();
	//QStringList lstTsFiles;
	//lstTsFiles << "D:/CCS/ccsexport/ccsexport_en.ts"
	//	<< "D:/CCS/ccsexport/common_en.ts";

	//生成一份所有ts数据的以类名归类的翻译数据
	int nClass = 0;
	int nCount = 0;
	int nUnfinished = 0;
	int nObsolete = 0;
	int nVanished = 0;
	for (QString strTsFile : lstTsFiles)
	{
		XmlAPI xml(strTsFile);
		if (!xml.Read())
		{
			continue;
		}

		ClassTranslatorData* pClass = nullptr;
		QDomElement nodeContext = xml.mRoot.firstChildElement("context");
		while (!nodeContext.isNull())
		{
			QDomElement nodeName = nodeContext.firstChildElement("name");
			if (nodeName.isNull())
			{
				continue;
			}
			QString strClassName = nodeName.text();
			if (mapAllClassTranslatorData.contains(strClassName))
			{
				pClass = mapAllClassTranslatorData[strClassName];
			}
			else
			{
				pClass = new ClassTranslatorData;
				mapAllClassTranslatorData[strClassName] = pClass;
				nClass++;
			}


			QDomElement nodeMessage = nodeContext.firstChildElement("message");
			while (!nodeMessage.isNull())
			{
				QDomElement nodeSource = nodeMessage.firstChildElement("source");
				QDomElement nodeTranslator = nodeMessage.firstChildElement("translation");
				QString strSource = nodeSource.text();
				QString strTranslator = nodeTranslator.text();
				QString strType = nodeTranslator.attribute("type");
				if (strType == "unfinished")
				{
					nUnfinished++;
				}
				else if (strType == "obsolete")
				{
					nObsolete++;
				}
				else if (strType == "vanished")
				{
					nVanished++;
				}

				if (!strSource.isEmpty() && !strTranslator.isEmpty())
				{
					pClass->Add(strSource, strTranslator);
					nCount++;
				}

				nodeMessage = nodeMessage.nextSiblingElement("message");
			}

			nodeContext = nodeContext.nextSiblingElement("context");
		}
	}

	Tip();
	Tip();
	Tip();
	Tip(QString("共发现类名 %1 个，字段 %2 条").arg(nClass).arg(nCount));
	Tip(QString("其中 未完成(unfinished) %1 条，已消失(vanished) %2 条，过时的(obsolete) %3 条")
		.arg(nUnfinished).arg(nVanished).arg(nObsolete));
	QStringList keys = mapAllClassTranslatorData.keys();
	Tip(QString("类名列表：\n") + keys.join("\n"));


	//使用生成的翻译数据，填充所有ts文件中未翻译的内容
	//注意：只在同类名的翻译数据中查找同名字段的翻译内容填充，这样基本都是应该翻译为一样的
	//而在不同类中，同一个字段名可能会翻译得不一样
	int nChanged = 0;
	QStringList lstDetails;
	for (QString strFile : lstTsFiles)
	{
		XmlAPI h(strFile);
		if (!h.Read())
		{
			continue;
		}

		QDomElement nodeContext = h.mRoot.firstChildElement("context");
		while (!nodeContext.isNull())
		{
			QDomElement nodeName = nodeContext.firstChildElement("name");
			if (nodeName.isNull())
			{
				continue;
			}
			QString strClassName = nodeName.text();

			QDomElement nodeMessage = nodeContext.firstChildElement("message");
			while (!nodeMessage.isNull())
			{
				QDomElement nodeSource = nodeMessage.firstChildElement("source");
				QDomElement nodeTranslator = nodeMessage.firstChildElement("translation");
				QString strSource = nodeSource.text();
				QString strTranslator = nodeTranslator.text();

				QString strType = nodeTranslator.attribute("type");
				if (strTranslator.isEmpty() || strType == "unfinished")
				{
					if (mapAllClassTranslatorData.contains(strClassName))
					{
						//if (strClassName == "DeviceAPI")
						//{
						//	int nn = 0;
						//}
						QString strNewTranslator = mapAllClassTranslatorData[strClassName]->Find(strSource);
						if (strNewTranslator.isEmpty())
						{
							nodeMessage = nodeMessage.nextSiblingElement("message");
							continue;
						}
						//nodeTranslator.setNodeValue(strTranslator);
						//nodeTranslator.removeAttribute("type");

						//替换translation节点
						QDomElement nodeNewTranslation = h.mDoc.createElement("translation");
						QDomText nodeText = h.mDoc.createTextNode(strNewTranslator);
						nodeText.setNodeValue(strNewTranslator);
						nodeNewTranslation.appendChild(nodeText);
						nodeMessage.removeChild(nodeTranslator);
						nodeMessage.appendChild(nodeNewTranslation);

						lstDetails << "[" + strFile + "][" + strClassName + "] " + strSource + " -> " + strNewTranslator;
						nChanged++;
					}
				}

				nodeMessage = nodeMessage.nextSiblingElement("message");
			}

			nodeContext = nodeContext.nextSiblingElement("context");
		}
		h.Write();
	}


	Tip();
	Tip();
	Tip();
	Tip(QString("自动翻译了 %1 条字段:").arg(nChanged));
	Tip(lstDetails.join("\n"));
	Tip();
	Tip();
	Tip();
}
