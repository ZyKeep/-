﻿#ifndef XmlAPI_H
#define XmlAPI_H

#include <QDomElement>
#include <QDomDocument>

//自己封装的方便操作xml文件的类
class XmlAPI
{
public:
	XmlAPI(QString strXmlFilePath);

	//读相关
	bool Read();
	QDomElement GetChild(QDomElement& node, QString name);
	QString GetChildAttr(QDomElement& node, QString name);
	QDomElement GetRootChild(QString name);
	QList<QDomElement> GetChilds(QDomElement& node, QString name);
	QString GetAttr(QDomElement &node, QString name);

	//写相关
	void Create();
	bool Write();
	QDomElement AddRootChild(QString name);
	QDomElement AddChild(QDomElement &node, QString name);						//添加子节点
	QDomElement AddChildAttr(QDomElement &node, QString name, QString text);	//添加子节点，同时设value属性
	QDomElement AddChildAttr(QDomElement &node, QString name, int text);
	QDomElement AddChildAttr(QDomElement &node, QString name, bool text);
	void UpdateChildAttr(QDomElement &node, QString name, QString text);

public:
	QString mXmlFilePath;
	QDomDocument mDoc;
	QDomElement mRoot;
};

#endif
