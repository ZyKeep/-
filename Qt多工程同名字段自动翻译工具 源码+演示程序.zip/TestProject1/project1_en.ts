<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>CommonClassA</name>
    <message>
        <source>公共类A的翻译测试字段</source>
        <translation>CommonClassATranslatorTest</translation>
    </message>
    <message>
        <source>字段1</source>
        <translation>text1</translation>
    </message>
    <message>
        <source>字段2</source>
        <translation>text2</translation>
    </message>
    <message>
        <source>字段3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段5</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CommonClassB</name>
    <message>
        <source>公共类B的翻译测试字段</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段5</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TestProject1</name>
    <message>
        <source>工程A字段</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段1</source>
        <translation>text1</translation>
    </message>
    <message>
        <source>字段2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>字段5</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TestProject1Class</name>
    <message>
        <source>TestProject1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
