﻿#include "TestProject1.h"

TestProject1::TestProject1(QWidget *parent)
    : QMainWindow(parent)
{
	ui.setupUi(this);

	QString str = tr("工程A字段");
	str = tr("字段1");
	str = tr("字段2");
	str = tr("字段3");
	str = tr("字段4");
	str = tr("字段5");
}

TestProject1::~TestProject1()
{}
