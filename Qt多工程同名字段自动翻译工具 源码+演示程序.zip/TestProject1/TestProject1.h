﻿#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_TestProject1.h"

class TestProject1 : public QMainWindow
{
    Q_OBJECT

public:
    TestProject1(QWidget *parent = nullptr);
    ~TestProject1();

private:
    Ui::TestProject1Class ui;
};
