/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you want to add, delete, or rename functions or slots, use
** Qt Designer to update this file, preserving your code.
**
** You should not define a constructor or destructor in this file.
** Instead, write your code in functions called init() and destroy().
** These will automatically be called by the form's constructor and
** destructor.
*****************************************************************************/
#include "qapplication.h"
#include "chessgame.h"
#include "qmessagebox.h"

void ConfigForm::initializeAll( CChessGame * game )
{
    QString str;
    const char** engines = NULL;
    
    chessGame = game;
    redIsMan = true;
    blackIsMan = true;
    blackOnTop = true;    
    /* Initialize the combobox for search engines */
    engines = game->getEngineList();
    
    for (int i = 0; engines[i] != NULL; i++)
    {
        str = engines[i];
        comboEngine->insertItem(str);
    }
    computerEngine = game->getBestEngine();
    computerLevel = 3;
    updateUI(true);
}


void ConfigForm::buttonOK_clicked()
{
    updateUI(false);
    applyChanges();
    hide();
}


void ConfigForm::buttonCancel_clicked()
{
    /* restore previous settings */
    updateUI(true);
    hide();
}


void ConfigForm::updateUI( bool refreshUI )
{
    if (refreshUI)
    {
        comboRedPlayer->setCurrentItem(redIsMan ? 0: 1);
        comboBlackPlayer->setCurrentItem(blackIsMan ? 0 : 1);
        comboWhoIsOnTop->setCurrentItem(blackOnTop ? 1 : 0);
        comboEngine->setCurrentItem(computerEngine);
        comboComputerLevel->setCurrentItem(computerLevel - 1);
    }
    else
    {
        redIsMan = (comboRedPlayer->currentItem() == 0);
        blackIsMan = (comboBlackPlayer->currentItem() == 0);
        blackOnTop = (comboWhoIsOnTop->currentItem() == 1);
        computerEngine = comboEngine->currentItem();
        computerLevel = comboComputerLevel->currentItem() + 1;
    }
}


void ConfigForm::applyChanges()
{
    if (!redIsMan || !blackIsMan)
    {
        chessGame->setEngine(chessGame->createEngine(computerEngine));
        chessGame->getEngine()->SetSearchDepth(computerLevel);
    }
    chessGame->initChessBoard();
    if (!blackOnTop)
        chessGame->invertBoard();
}


void ConfigForm::comboRedPlayer_activated( int )
{
    if (comboRedPlayer->currentItem())
    {
        if (comboBlackPlayer->currentItem())
        {
            QMessageBox::critical(this, tr("NO"), 
                                  tr("Only one player can be computer"));
            comboRedPlayer->setCurrentItem(0);
        }
        else
        {
            comboWhoIsOnTop->setCurrentItem(0);
            comboWhoIsOnTop->setEnabled(false);
        }
    }
    else
        comboWhoIsOnTop->setEnabled(true);
}


void ConfigForm::comboBlackPlayer_activated( int )
{
    if (comboBlackPlayer->currentItem())
    {
        if (comboRedPlayer->currentItem())
        {
            QMessageBox::critical(this, tr("NO"), 
                                  tr("Only one player can be computer"));
            comboBlackPlayer->setCurrentItem(0);
        }
        else
        {
            comboWhoIsOnTop->setCurrentItem(1);
            comboWhoIsOnTop->setEnabled(false);
        }
    }
    else
        comboWhoIsOnTop->setEnabled(true);
}
