#include "frmmain.h"
#include "ui_frmmain.h"
#include "myhelper.h"
#include "iconhelper.h"

#define TextColor QColor(255,255,255)
#define Plot_NoColor QColor(0,0,0,0)

#define TextWidth 1
#define LineWidth 1
#define DotWidth 3

frmMain::frmMain(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmMain)
{
    ui->setupUi(this);

    this->InitStyle();
    this->InitForm();
    this->InitPlot();
    this->ChangePlotColor();
}

frmMain::~frmMain()
{
    delete ui;
}

void frmMain::InitStyle()
{
    this->setProperty("Form", true);
    this->setWindowTitle(ui->lab_Title->text());
    this->setGeometry(qApp->desktop()->availableGeometry());
    this->setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint);
    IconHelper::Instance()->SetIcon(ui->lab_Ico, QChar(0xf012));
    IconHelper::Instance()->SetIcon(ui->btnMenu_Close, QChar(0xf00d));
    connect(ui->btnMenu_Close, SIGNAL(clicked()), this, SLOT(close()));
}

void frmMain::InitForm()
{
    xTickCount = 10;
    yTickCount = 10;
    currentCount = 1000;
    currentColor = 0;
    App::AppStyle = ":/image/dev.css";

    Plot_DotColor.append(QColor(5, 189, 251));
    Plot_LineColor.append(QColor(41, 138, 220));
    Plot_BGColor.append(QColor(41, 138, 220, 80));

    Plot_DotColor.append(QColor(236, 110, 0));
    Plot_LineColor.append(QColor(246, 98, 0));
    Plot_BGColor.append(QColor(246, 98, 0, 80));

    Plot_DotColor.append(QColor(255, 127, 0));
    Plot_LineColor.append(QColor(255, 139, 0));
    Plot_BGColor.append(QColor(255, 139, 0, 80));

    Plot_DotColor.append(QColor(255, 0, 254));
    Plot_LineColor.append(QColor(255, 52, 178));
    Plot_BGColor.append(QColor(255, 52, 178, 80));

    Plot_DotColor.append(QColor(254, 0, 0));
    Plot_LineColor.append(QColor(255, 48, 48));
    Plot_BGColor.append(QColor(255, 48, 48, 80));

    Plot_DotColor.append(QColor(229, 230, 250));
    Plot_LineColor.append(QColor(237, 237, 237));
    Plot_BGColor.append(QColor(237, 237, 237, 80));

    Plot_DotColor.append(QColor(106, 139, 34));
    Plot_LineColor.append(QColor(106, 142, 34));
    Plot_BGColor.append(QColor(106, 142, 34, 80));
}

void frmMain::InitPlot()
{
    //设置纵坐标名称
    ui->plot->yAxis->setLabel("角度值(单位:度)");

    //设置坐标颜色/坐标名称颜色
    ui->plot->yAxis->setLabelColor(TextColor);
    ui->plot->xAxis->setTickLabelColor(TextColor);
    ui->plot->yAxis->setTickLabelColor(TextColor);
    ui->plot->xAxis->setBasePen(QPen(TextColor, TextWidth));
    ui->plot->yAxis->setBasePen(QPen(TextColor, TextWidth));
    ui->plot->xAxis->setTickPen(QPen(TextColor, TextWidth));
    ui->plot->yAxis->setTickPen(QPen(TextColor, TextWidth));
    ui->plot->xAxis->setSubTickPen(QPen(TextColor, TextWidth));
    ui->plot->yAxis->setSubTickPen(QPen(TextColor, TextWidth));

    //设置画布背景色
    QLinearGradient plotGradient;
    plotGradient.setStart(0, 0);
    plotGradient.setFinalStop(0, 350);
    plotGradient.setColorAt(0, QColor(80, 80, 80));
    plotGradient.setColorAt(1, QColor(50, 50, 50));
    ui->plot->setBackground(plotGradient);

    //设置坐标背景色
    QLinearGradient axisRectGradient;
    axisRectGradient.setStart(0, 0);
    axisRectGradient.setFinalStop(0, 350);
    axisRectGradient.setColorAt(0, QColor(80, 80, 80));
    axisRectGradient.setColorAt(1, QColor(30, 30, 30));
    ui->plot->axisRect()->setBackground(axisRectGradient);

    //设置图例提示位置及背景色
    ui->plot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignTop | Qt::AlignRight);
    ui->plot->legend->setBrush(QColor(255, 255, 255, 200));

    ui->plot->addGraph();
    ui->plot->graph(0)->setName("角度值(单位:度)");

    //设置静态曲线的横坐标范围及自适应横坐标
    ui->plot->xAxis->setRange(0, currentCount + 1, Qt::AlignLeft);
    ui->plot->xAxis->setAutoTickCount(xTickCount);
    ui->plot->yAxis->setAutoTickCount(yTickCount);
    ui->plot->graph(0)->rescaleAxes();
    ui->plot->replot();
}

void frmMain::ChangePlotColor()
{
    ui->plot->graph(0)->setPen(QPen(Plot_LineColor[currentColor], LineWidth));
    ui->plot->graph(0)->setScatterStyle(
                QCPScatterStyle(QCPScatterStyle::ssCircle,
                                QPen(Plot_DotColor[currentColor], LineWidth),
                                QBrush(Plot_DotColor[currentColor]), DotWidth));
    if (ui->ckBackground->isChecked()) {
        ui->plot->graph(0)->setBrush(QBrush(Plot_BGColor[currentColor]));
    }
    ui->plot->replot();
}

void frmMain::LoadPlot()
{
    plot_keys.clear();
    plot_values.clear();

    //如果是基数个数则长度要-1
    if (currentCount % 2 != 0) {
        currentCount--;
    }

    for (int i = 0; i < currentCount / 2; i++) {
        plot_keys.append(i);
    }
    for (int i = 0; i < currentCount; i = i + 2) {
        qint16 value = StrHexToShort(QString("%1%2").arg(plot_data[i]).arg(plot_data[i + 1]));
        qDebug() << plot_data[i] << plot_data[i + 1] << value << i << currentCount;
        plot_values.append(value);
    }
    ui->plot->graph(0)->setData(plot_keys, plot_values);
    ui->plot->xAxis->setAutoTickCount(xTickCount);
    ui->plot->yAxis->setAutoTickCount(yTickCount);
    ui->plot->graph(0)->rescaleAxes();
    ui->plot->replot();
}

qint16 frmMain::StrHexToShort(QString strHex)
{
    bool ok;
    return strHex.toUShort(&ok, 16);
}

void frmMain::on_btnLoad_clicked()
{
    QString filter = "数据文件 (*.txt *.dat)";
    QString fileName = QFileDialog::getOpenFileName(0, "选择文件", QCoreApplication::applicationDirPath(), filter);
    QString data;
    if (fileName != "") {
        QFile file(fileName);
        file.open(QFile::ReadOnly | QIODevice::Text);
        data = QLatin1String(file.readAll());
        file.close();

        plot_data = data.split(" ");
        currentCount = plot_data.length();
        ui->labInfo->setText(QString("共 %1 条数据").arg(currentCount));
        LoadPlot();
    }
}

void frmMain::on_btnSkin_clicked()
{
    if (App::AppStyle == ":/image/dev.css") {
        currentColor = 1;
        App::AppStyle = ":/image/black.css";
    } else if (App::AppStyle == ":/image/black.css") {
        currentColor = 2;
        App::AppStyle = ":/image/brown.css";
    } else if (App::AppStyle == ":/image/brown.css") {
        currentColor = 3;
        App::AppStyle = ":/image/blue.css";
    } else if (App::AppStyle == ":/image/blue.css") {
        currentColor = 4;
        App::AppStyle = ":/image/gray.css";
    } else if (App::AppStyle == ":/image/gray.css") {
        currentColor = 5;
        App::AppStyle = ":/image/white.css";
    } else if (App::AppStyle == ":/image/white.css") {
        currentColor = 6;
        App::AppStyle = ":/image/silvery.css";
    } else if (App::AppStyle == ":/image/silvery.css") {
        currentColor = 0;
        App::AppStyle = ":/image/dev.css";
    }
    this->ChangePlotColor();
    myHelper::SetStyle(App::AppStyle);
}

void frmMain::on_ckXGrid_stateChanged(int arg1)
{
    bool value = (arg1 == 0 ? false : true);
    ui->plot->xAxis->grid()->setSubGridVisible(value);
    ui->plot->replot();
}

void frmMain::on_ckYGrid_stateChanged(int arg1)
{
    bool value = (arg1 == 0 ? false : true);
    ui->plot->yAxis->grid()->setSubGridVisible(value);
    ui->plot->replot();
}

void frmMain::on_ckText_stateChanged(int arg1)
{
    bool value = (arg1 == 0 ? false : true);
    ui->plot->legend->setVisible(value);
    ui->plot->replot();
}

void frmMain::on_ckBackground_stateChanged(int arg1)
{
    bool value = (arg1 == 0 ? false : true);
    if (value) {
        ui->plot->graph(0)->setBrush(QBrush(Plot_BGColor[currentColor]));
    } else {
        ui->plot->graph(0)->setBrush(QBrush(Plot_NoColor));
    }
    ui->plot->replot();
}

void frmMain::on_ckMove_stateChanged(int arg1)
{
    bool value = (arg1 == 0 ? false : true);
    if (value) {
        ui->plot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    } else {
        ui->plot->setInteractions(QCP::iSelectOther);
    }
    ui->plot->replot();
}
