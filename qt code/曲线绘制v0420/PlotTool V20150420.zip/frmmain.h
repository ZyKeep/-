#ifndef FRMMAIN_H
#define FRMMAIN_H

#include <QWidget>
#include "qcustomplot.h"

namespace Ui
{
class frmMain;
}

class frmMain : public QWidget
{
    Q_OBJECT

public:
    explicit frmMain(QWidget *parent = 0);
    ~frmMain();

private slots:
    void LoadPlot();
    void on_btnLoad_clicked();
    void on_btnSkin_clicked();
    void on_ckXGrid_stateChanged(int arg1);
    void on_ckYGrid_stateChanged(int arg1);
    void on_ckText_stateChanged(int arg1);
    void on_ckBackground_stateChanged(int arg1);
    void on_ckMove_stateChanged(int arg1);

private:
    Ui::frmMain *ui;

    int xTickCount;
    int yTickCount;
    int currentCount;
    int currentColor;
    QStringList plot_data;
    QVector<double> plot_keys;
    QVector<double> plot_values;
    qint16 StrHexToShort(QString strHex);

    QList<QColor> Plot_DotColor;
    QList<QColor> Plot_LineColor;
    QList<QColor> Plot_BGColor;

    void InitStyle();
    void InitForm();
    void InitPlot();
    void ChangePlotColor();

};

#endif // FRMMAIN_H
