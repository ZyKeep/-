#include "widget.h"
#include "ui_widget.h"
#include "mylrc.h"
#include <QDebug>
#include <QMenu>
#include <QFileDialog>
#include <QDir>
#include <QTextCodec>
#include <QMessageBox>
#include <QCloseEvent>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setFixedSize(size());

    mediaList = new QMediaPlaylist(this);
    player = new QMediaPlayer(this);

    player->setPlaylist(mediaList);
    isVolume = true;
    isSliderPressed = false;
    player->setVolume(50);

    connect(player,SIGNAL(durationChanged(qint64)),SLOT(durationChanged(qint64)));
    connect(player,SIGNAL(positionChanged(qint64)),SLOT(positionChanged(qint64)));
    connect(player,SIGNAL(stateChanged(QMediaPlayer::State)),SLOT(stateChange(QMediaPlayer::State)));
    connect(player,SIGNAL(currentMediaChanged(QMediaContent)),SLOT(currentMediaChanged(QMediaContent)));

    lrc = new MyLrc(0,windowTitle());
    lrc->show();

    ui->musicGroupBox->setTitle(windowTitle());
}

Widget::~Widget()
{
    delete lrc;
    delete ui;
}

void Widget::closeEvent(QCloseEvent *event)
{
    if(QMessageBox::information(this,windowTitle(),tr("你是否要退出？"),QMessageBox::Yes,QMessageBox::No) == QMessageBox::Yes)
    {
        lrc->close();
        event->accept();
    } else event->ignore();
}

void Widget::openSongs()
{
    QStringList fileList = QFileDialog::getOpenFileNames(this,tr("添加音乐"),QString(),QString("MP3 (*.mp3)"));
    addList(fileList);
}

void Widget::openDir()
{
    QString dirPath = QFileDialog::getExistingDirectory(this,tr("选择目录"));
    if(!QDir(dirPath).exists())
        return;
    QDir dir(dirPath);
    QStringList fileList = dir.entryList(QStringList()<<"*.mp3",QDir::Files);
    for(int i = 0;i < fileList.size();i ++)
        fileList[i] = dir.absoluteFilePath(fileList.at(i));
    addList(fileList);
}

void Widget::durationChanged(qint64 duration)
{
    ui->scheduleSlider->setRange(0,duration);
    ui->scheduleSlider->setValue(0);
}

void Widget::positionChanged(qint64 position)
{
    if(!isSliderPressed)
        ui->scheduleSlider->setValue(position);

    if(!lrcMap.isEmpty())
    {
        qint64 prev = 0,next = 0;
        foreach(qint64 value,lrcMap.keys())
        {
            if(position >= value)
                prev = value;
            else{
                next = value;
                break;
            }
        }

        if(next == 0)
            next = ui->scheduleSlider->maximum();

        QString currentLrc = lrcMap.value(prev);
        if(currentLrc.length() < 2)
            currentLrc = windowTitle();
        if(currentLrc != lrc->text())
        {
            lrc->setText(currentLrc);
            qint64 intervalTime = next - prev;
            lrc->startLrcMask(intervalTime);
        }
    }
}

void Widget::stateChange(QMediaPlayer::State state)
{
    if(state == QMediaPlayer::PlayingState)
        ui->PSToolButton->setIcon(QIcon(":/image/pause.ico"));
    else ui->PSToolButton->setIcon(QIcon(":/image/play.ico"));

    if(state == QMediaPlayer::StoppedState)
        ui->musicGroupBox->setTitle(windowTitle());
}

void Widget::currentMediaChanged(QMediaContent)
{
    lrc->setText(windowTitle());

    int index = mediaList->currentIndex();
    if(index == -1)
        return;

    ui->playlistTableWidget->selectRow(index);
    ui->playlistTableWidget->setFocus();

    QString songName = playList.at(index);
    ui->musicGroupBox->setTitle(QFileInfo(songName).baseName());

    decodeLrc(songName.left(songName.length() - 4) + ".lrc");
}

void Widget::removeCurrentIndex()
{
    playList.removeAt(currentIndex);
    ui->playlistTableWidget->removeRow(currentIndex);

    mediaList->removeMedia(currentIndex);
}

void Widget::clearList()
{
    player->stop();
    playList.clear();
    mediaList->clear();
    while(ui->playlistTableWidget->rowCount())
        ui->playlistTableWidget->removeRow(0);
}

void Widget::addList(QStringList list)
{
    foreach(QString fileName,list)
    {
        if(playList.contains(fileName))
            continue;
        playList.append(fileName);

        mediaList->addMedia(QUrl::fromLocalFile(fileName));
        ui->playlistTableWidget->insertRow(ui->playlistTableWidget->rowCount());
        for(int i = 0;i < ui->playlistTableWidget->columnCount();i ++)
            ui->playlistTableWidget->setItem(ui->playlistTableWidget->rowCount() - 1,i,new QTableWidgetItem);
        ui->playlistTableWidget->item(ui->playlistTableWidget->rowCount() - 1,0)->setText(QFileInfo(fileName).baseName());
    }
}

void Widget::decodeLrc(QString fileName)
{
    lrcMap.clear();

    QFile file(fileName);
    if(!file.open(QFile::ReadOnly | QFile::Text))
    {
        lrc->stopLrcMask();
        return;
    }
    QString text = QTextCodec::codecForLocale()->toUnicode(file.readAll());
    file.close();

    QRegExp time("\\[(\\d{2}):(\\d{2})\\.(\\d{2})\\]");
    foreach(QString oneLine,text.split("\n"))
    {
        QString temp = oneLine;
        temp.replace(time,"");
        int pos = time.indexIn(oneLine);
        while(pos != -1)
        {
            lrcMap.insert(time.cap(1).toInt()*60000 + time.cap(2).toInt()*1000 + time.cap(3).toInt()*10,temp);
            pos = time.indexIn(oneLine,pos+1);
        }
    }
}

void Widget::on_playlistTableWidget_customContextMenuRequested(const QPoint &pos)
{
    QMenu menu;

    if(ui->playlistTableWidget->itemAt(pos))
    {
        currentIndex = ui->playlistTableWidget->rowAt(pos.y());
        menu.addAction(tr("移除本曲"),this,SLOT(removeCurrentIndex()));
        menu.addSeparator();
    }

    menu.addAction(tr("添加歌曲"),this,SLOT(openSongs()));
    menu.addAction(tr("添加目录"),this,SLOT(openDir()));
    menu.addSeparator();
    menu.addAction(tr("移除所有"),this,SLOT(clearList()));
    menu.exec(QCursor::pos());
}

void Widget::on_playlistTableWidget_cellDoubleClicked(int row, int )
{
    mediaList->setCurrentIndex(row);
    player->play();
}

void Widget::on_scheduleSlider_sliderPressed()
{
    isSliderPressed = true;
}

void Widget::on_scheduleSlider_sliderReleased()
{
    isSliderPressed = false;
    if(player->state() == QMediaPlayer::PlayingState)
        player->setPosition(qint64(ui->scheduleSlider->value()));
}


void Widget::on_volumeSlider_sliderMoved(int position)
{
    if(isVolume)
    {
        player->setVolume(position);
        if(ui->volumeSlider->value() >= ui->volumeSlider->maximum()/2)
            ui->volumeToolButton->setIcon(QIcon(":/image/audio_volume_high.ico"));
        else ui->volumeToolButton->setIcon(QIcon(":/image/audio_volume_low.ico"));
    }
}

void Widget::on_volumeToolButton_clicked()
{
    isVolume ^= 1;
    if(isVolume)
    {
        player->setVolume(ui->volumeSlider->value());
        if(ui->volumeSlider->value() >= ui->volumeSlider->maximum()/2)
            ui->volumeToolButton->setIcon(QIcon(":/image/audio_volume_high.ico"));
        else ui->volumeToolButton->setIcon(QIcon(":/image/audio_volume_low.ico"));
    }
    else {
        player->setVolume(0);
        ui->volumeToolButton->setIcon(QIcon(":/image/audio_volume_no.ico"));
    }
}

void Widget::on_PSToolButton_clicked()
{
    if(player->state() == QMediaPlayer::PlayingState)
        player->pause();
    else if(!mediaList->isEmpty())
        player->play();
}

void Widget::on_prevToolButton_clicked()
{
    mediaList->previous();
}

void Widget::on_nextToolButton_clicked()
{
    mediaList->next();
}

void Widget::on_orderComboBox_activated(const QString &arg1)
{
    if(arg1.contains("顺序播放"))
        mediaList->setPlaybackMode(QMediaPlaylist::Sequential);
    if(arg1.contains("单曲播放"))
        mediaList->setPlaybackMode(QMediaPlaylist::CurrentItemOnce);
    if(arg1.contains("单曲循环"))
        mediaList->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);
    if(arg1.contains("列表循环"))
        mediaList->setPlaybackMode(QMediaPlaylist::Loop);
    if(arg1.contains("随机播放"))
        mediaList->setPlaybackMode(QMediaPlaylist::Random);
}

void Widget::on_lrcToolButton_clicked()
{
    lrc->setVisible(lrc->isVisible() ^ 1);
    setFocus();
}
