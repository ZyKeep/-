#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QString>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QMap>
class MyLrc;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

protected:
    void closeEvent(QCloseEvent *event);
private slots:
    void openSongs();
    void openDir();
    void durationChanged(qint64 duration);
    void positionChanged(qint64 position);
    void stateChange(QMediaPlayer::State state);
    void currentMediaChanged(QMediaContent );
    void removeCurrentIndex();
    void clearList();

    void on_playlistTableWidget_customContextMenuRequested(const QPoint &pos);

    void on_playlistTableWidget_cellDoubleClicked(int row, int);

    void on_volumeSlider_sliderMoved(int position);

    void on_scheduleSlider_sliderReleased();

    void on_scheduleSlider_sliderPressed();

    void on_volumeToolButton_clicked();

    void on_PSToolButton_clicked();

    void on_prevToolButton_clicked();

    void on_nextToolButton_clicked();

    void on_orderComboBox_activated(const QString &arg1);

    void on_lrcToolButton_clicked();

private:
    void addList(QStringList list);
    void decodeLrc(QString fileName);

    Ui::Widget *ui;

    QStringList playList;
    QMediaPlaylist *mediaList;
    QMediaPlayer *player;
    bool isVolume;
    bool isSliderPressed;
    int currentIndex;
    MyLrc *lrc;
    QMap<qint64,QString> lrcMap;
};

#endif // WIDGET_H
