#include "mylrc.h"
#include <QPainter>
#include <QTimer>
#include <QMouseEvent>
#include <QApplication>
#include <QDesktopWidget>
#include <QDebug>

MyLrc::MyLrc(QWidget *parent, QString title) :
    QLabel(parent),title(title)
{
    setWindowFlags(Qt::Tool | Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
    setFocusPolicy(Qt::NoFocus);

    setAttribute(Qt::WA_TranslucentBackground);
    setText(title);

    setFixedSize(800,60);

    linearGradient.setStart(0,10);
    linearGradient.setFinalStop(0,40);
    linearGradient.setColorAt(0.1,QColor(14,179,255));
    linearGradient.setColorAt(0.5,QColor(114,32,255));
    linearGradient.setColorAt(0.9,QColor(14,179,255));

    maskLinearGradient.setStart(0,10);
    maskLinearGradient.setFinalStop(0,40);
    maskLinearGradient.setColorAt(0.1,QColor(222,54,4));
    maskLinearGradient.setColorAt(0.5,QColor(255,72,16));
    maskLinearGradient.setColorAt(0.9,QColor(222,54,4));

    font.setFamily("楷体");
    font.setBold(true);
    font.setPointSize(30);

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),SLOT(timeout()));
    lrcMaskWidth = 0;
    lrcMaskWidthInterval = 0;

    move((QApplication::desktop()->width() - width())/2,QApplication::desktop()->height() - height() * 2);
}

void MyLrc::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setFont(font);

    painter.setPen(QColor(0,0,0,200));
    painter.drawText(1,1,800,60,Qt::AlignLeft | Qt::AlignVCenter,text());
    painter.setPen(QPen(linearGradient,0));
    painter.drawText(1,1,800,60,Qt::AlignLeft | Qt::AlignVCenter,text());
    painter.setPen(QPen(maskLinearGradient,0));
    painter.drawText(1,1,lrcMaskWidth,60,Qt::AlignLeft | Qt::AlignVCenter,text());
}

void MyLrc::startLrcMask(qint64 intervalTime)
{
    qreal count = intervalTime / 30;

    lrcMaskWidthInterval = 800 / count;
    lrcMaskWidth = 0;
    timer->start(30);
}

void MyLrc::stopLrcMask()
{
    timer->stop();
    lrcMaskWidth = 0;
    update();
}

void MyLrc::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
        offset = event->globalPos() - frameGeometry().topLeft();
}

void MyLrc::mouseMoveEvent(QMouseEvent *event)
{
    if(event->buttons() & Qt::LeftButton)
    {
        setCursor(Qt::PointingHandCursor);
        move(event->globalPos() - offset);
    }
}

void MyLrc::timeout()
{
    lrcMaskWidth += lrcMaskWidthInterval;
    lrcMaskWidth = qMin(lrcMaskWidth , qreal(width()));
    update();
}
